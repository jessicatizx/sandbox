let fontPressStart;
let sandboxCoins = 2;
let img, coinImg, bgImage;

function preload() {
  // Load the font file
  fontPressStart = loadFont('PressStart2P-Regular.ttf');

  // Load images
  img = loadImage('image1.png'); // Main image
  coinImg = loadImage('image3.png'); // Coin image
  bgImage = loadImage('image2.png'); // Background image
}

function setup() {
  createCanvas(1440, 1024);
  textFont(fontPressStart);
  textAlign(CENTER, CENTER);
}

function draw() {
  // Draw the background gradient
  background(0);
  image(bgImage, 0, 0, width, height); // Draw background image

  // Background gradient overlay
  let gradient = drawingContext.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, '#000000');
  gradient.addColorStop(0.25, '#070107');
  gradient.addColorStop(0.61, '#0F010E');
  gradient.addColorStop(0.87, '#160215');
  gradient.addColorStop(1, '#1D031C');
  drawingContext.fillStyle = gradient;
  rect(0, 0, width, height);

  // Main image with transparency
  tint(255, 77); // Set image transparency
  image(img, 71, 147, 1297, 729);
  noTint();

  // Overlay rectangles
  fill(255, 77);
  rect(92, 169, 547, 74);
  rect(163, 903, 1115, 74);

  // Texts
  fill(255, 77);
  textSize(21);
  text('Requires 4 Sandbox Coins', 92 + 547 / 2, 169 + 74 / 2);

  textSize(25);
  text('‘A Kind of Alchemy\': The Work of Art in the Age of Artificial Intelligence (2023)', 163 + 1115 / 2, 903 + 74 / 2);

  textSize(26);
  text(`Sandbox Coins: ${sandboxCoins}`, 848 + 100 / 2, 66 + 50 / 2);

  // Arrows
  fill(255, 77);
  drawArrow(1395, 496, 25.5, 48);
  push();
  translate(70, 0);
  scale(-1, 1);
  drawArrow(-44.5, 496, 25.5, 48);
  pop();

  // Watch now button
  fill(255, 77);
  rect(572, 744, 296, 88, 40);
  textSize(24);
  fill(255);
  text('Watch now', 572 + 296 / 2, 744 + 88 / 2);

  // Viewing starts text
  textSize(99);
  fill('#F0AD5E');
  text('VIEWING', width / 2, 433);
  fill('#E3D0BE');
  text('STARTS', width / 2, 433 + 99);

  // Coin image
  image(coinImg, 1274, 41, 66, 75);
}

function drawArrow(x, y, w, h) {
  beginShape();
  vertex(x, y);
  vertex(x + w, y + h / 2);
  vertex(x, y + h);
  endShape(CLOSE);
}
